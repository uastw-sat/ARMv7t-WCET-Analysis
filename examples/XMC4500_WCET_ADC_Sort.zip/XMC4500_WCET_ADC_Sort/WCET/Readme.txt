execute WCET: go to bin folder and execute:
oswa firmware.elf -s xmc4500.osx -f flowfacts.ffx main

generate flowfacts:
mkff firmware.elf main
